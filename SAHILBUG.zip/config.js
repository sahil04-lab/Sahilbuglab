module.exports = {
    ownerId: 5514813704,//change your id telegram 
    telegramBotToken: "8755073811:AAGSw8pcXG3MVxb-yJPTHDXORNCPEUh-qts",///the bot is being administered in your channel
    sessionName: "session",
    chanelid: "@kpksahil",///change your username channel 
    chatgrupid: "@kpksahilgaming",///change your grup public,do not grup private 
    thumburl: "https://files.catbox.moe/8qctxz.png"
};